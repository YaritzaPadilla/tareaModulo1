
package tareas1;

public class NumerosPares {
    public static void main(String[] args) {
        System.out.println("Numeros pares del 2 al 100:");
        
        for (int i = 2; i<= 100; i += 2) {
            System.out.println(i);
        }
    }
    
}
