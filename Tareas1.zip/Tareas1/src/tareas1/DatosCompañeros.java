
package tareas1;

public class DatosCompañeros {
    public static void main(String[] args){
        String[][] compañeros = {
            {"David", "Medina", "Mecatronica", "Scatec"},
            {"Yaritza", "Betanco", "Industrial", "Banco Occidente"},
            {"Neryn", "Aguilar", "Electronica", "CEMEX"},
            {"Lizeth", "Betanco", "Computacion", "Banco Atlantida"},
            {"Genesis", "Ponce", "Administracion", "IMSA"}   
        };
        
        System.out.println("Datos de los compañeros de clase:");
        System.out.println("--------------------------------------");
        for (int i = 0; i < compañeros.length; i++) {
           System.out.println("Nombre: " + compañeros[i][0]);
           System.out.println("Apellido: " + compañeros[i][1]);
           System.out.println("Carrera: " + compañeros[i][2]);
           System.out.println("Lugar de Trabajo: " + compañeros[i][3]);
           System.out.println("-------------------------------------");
                                                      
        }
    }
    
}
