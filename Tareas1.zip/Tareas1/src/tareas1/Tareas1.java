
package tareas1;

public class Tareas1 {

    
    public static void main(String[] args) {
        System.out.println("Hola, soy Yaritza Padilla");
    }
    
}
